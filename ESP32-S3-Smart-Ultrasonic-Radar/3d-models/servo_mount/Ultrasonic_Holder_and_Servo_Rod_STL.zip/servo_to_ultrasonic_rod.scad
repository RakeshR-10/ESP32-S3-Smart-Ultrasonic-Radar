
$fn=64;
module rod(){
    difference(){
        union(){
            translate([0,-3,0]) cube([70,6,4]);
            cylinder(d=18,h=6);
            translate([70,0,0]) cylinder(d=12,h=4);
            hull(){
                cylinder(d=12,h=4);
                translate([70,0,0]) cylinder(d=8,h=4);
            }
        }
        translate([0,0,-1]) cylinder(d=5.2,h=8);
        for(a=[45,135,225,315])
            translate([7*cos(a),7*sin(a),-1]) cylinder(d=2.6,h=8);
        translate([70,0,-1]) cylinder(d=3.2,h=8);
        hull(){
            translate([16,0,1]) cylinder(d=4,h=4);
            translate([55,0,1]) cylinder(d=4,h=4);
        }
    }
}
rod();
