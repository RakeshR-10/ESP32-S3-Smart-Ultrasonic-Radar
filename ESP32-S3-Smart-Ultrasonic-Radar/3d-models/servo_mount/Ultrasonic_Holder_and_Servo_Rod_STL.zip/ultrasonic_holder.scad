
$fn=64;
module holder(){
    difference(){
        union(){
            translate([-23,-12,0]) cube([46,24,3]);
            translate([-23,-12,0]) cube([4,24,22]);
            translate([19,-12,0]) cube([4,24,22]);
            translate([-19,-12,0]) cube([38,4,5]);
            translate([-19,8,0]) cube([38,4,4]);
            translate([-7,-18,0]) cube([14,6,6]);
            translate([0,-18,0]) cylinder(d=14,h=6);
        }
        translate([-19,-8,3]) cube([38,16,20]);
        translate([0,-18,0]) cylinder(d=3.2,h=10);
        translate([-21,-7,11]) rotate([0,90,0]) cylinder(d=2.6,h=6);
        translate([21,-7,11]) rotate([0,90,0]) cylinder(d=2.6,h=6);
    }
}
holder();
